package kr.co.OTZang.item.goods.admin;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class C_GoodsDAO {
	 @Autowired
	 private SqlSessionTemplate sqlSessionTemplate;
	 
	
	 
	 public List<C_GoodsDTO> getList(C_GoodsDTO dto) {  
		 return sqlSessionTemplate.selectList("Goods.list", dto);  
		 } 
	 

	 public void delete(String g_code) {
		 sqlSessionTemplate.selectOne("Goods.delete", g_code);
	 }
	 
	 public void insert(C_GoodsDTO dto) {
		 sqlSessionTemplate.selectOne("Goods.delete", dto);
	 }
	 
}
