package kr.co.OTZang.item.cart;

import java.util.List;

public interface CartService {
	//public String addCart(K_Cart cart);
	public List<K_Cart> getCartList();
	public void deleteCart(String c_code);
	public int updateCart(int c_count, int c_code);
	public int insertCart(K_Cart cart);
	//public List<K_Cart> getCartList(String c_uid);
	//public String delete(String c_code);
	//void ajaxTest(int c_code);


}
