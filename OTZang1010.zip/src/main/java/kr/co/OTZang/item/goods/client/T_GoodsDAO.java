package kr.co.OTZang.item.goods.client;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class T_GoodsDAO {
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public List<T_Goods> list(T_Goods goods, T_Criteria cri) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("goods", goods);
		cri.setStartNum((cri.getPageNum() - 1) * cri.getAmount());
		paramMap.put("criteria", cri);
		return sqlSessionTemplate.selectList("goods.list", paramMap);
	}

	public int total(T_Goods goods) {
		int total = sqlSessionTemplate.selectOne("goods.total", goods);
		return total;
	}
	
	public T_Goods detail(T_Goods goods) {
		return this.sqlSessionTemplate.selectOne("goods.detail", goods);
	}

}