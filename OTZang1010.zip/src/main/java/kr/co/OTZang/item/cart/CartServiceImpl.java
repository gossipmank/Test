package kr.co.OTZang.item.cart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;


@Service
public class CartServiceImpl implements CartService {
	
	@Autowired
	private K_CartDAO k_cartDAO;

	@Override
public List<K_Cart> getCartList() {
		List<K_Cart> cartList = k_cartDAO.getCartList();
		return this.k_cartDAO.getCartList();
}


	@Override
public void deleteCart(String c_code) {
		k_cartDAO.deleteCart(c_code);
}

	@Override
	public int updateCart(int c_count,int c_code) {
		 return this.k_cartDAO.updateCart(c_count,c_code);
	}
	
	@Override
	public int insertCart(K_Cart cart) {
		 return this.k_cartDAO.insertCart(cart);
	}
	
	
	
	
	

	
	//@Override
//public List<K_Cart> getCartList(@RequestParam String c_uid) {
		//List<K_Cart> cartList = k_cartDAO.getCartList(c_uid);
		//return this.k_cartDAO.getCartList(c_uid);


}
