package kr.co.OTZang.item.cart;

public class T_Cart {
	private String c_code;
	private String c_gcode;
	private String c_gname;
	private String c_gcate;
	private int c_gprice;
	private String c_gimg;
	private int c_count;
	private String c_uid;
	private String c_option;
	private int totalPrice;
	public String getC_code() {
		return c_code;
	}
	public void setC_code(String c_code) {
		this.c_code = c_code;
	}
	public String getC_gcode() {
		return c_gcode;
	}
	public void setC_gcode(String c_gcode) {
		this.c_gcode = c_gcode;
	}
	public String getC_gname() {
		return c_gname;
	}
	public void setC_gname(String c_gname) {
		this.c_gname = c_gname;
	}
	public String getC_gcate() {
		return c_gcate;
	}
	public void setC_gcate(String c_gcate) {
		this.c_gcate = c_gcate;
	}
	public int getC_gprice() {
		return c_gprice;
	}
	public void setC_gprice(int c_gprice) {
		this.c_gprice = c_gprice;
	}
	public String getC_gimg() {
		return c_gimg;
	}
	public void setC_gimg(String c_gimg) {
		this.c_gimg = c_gimg;
	}
	public int getC_count() {
		return c_count;
	}
	public void setC_count(int c_count) {
		this.c_count = c_count;
	}

	public String getC_uid() {
		return c_uid;
	}
	public void setC_uid(String c_uid) {
		this.c_uid = c_uid;
	}
	public String getC_option() {
		return c_option;
	}
	public void setC_option(String c_option) {
		this.c_option = c_option;
	}

	public int getTotalPrice() {
		return totalPrice;
	}
	@Override
	public String toString() {
		return "K_Cart [c_code=" + c_code + ", c_gcode=" + c_gcode + ", c_gname=" + c_gname + ", c_gcate=" + c_gcate
				+ ", c_gprice=" + c_gprice + ", c_gimg=" + c_gimg + ", c_count=" + c_count + ", c_gmstore="
				+ ", c_uid=" + c_uid + ", c_option=" + c_option + ", salePrice="  + ", totalPrice="
				+ totalPrice + "]";
	}
	
	
	
}
	