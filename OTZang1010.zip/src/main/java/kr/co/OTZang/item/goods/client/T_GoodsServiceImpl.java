package kr.co.OTZang.item.goods.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class T_GoodsServiceImpl implements T_GoodsService {

	@Autowired
	private T_GoodsDAO goodsDAO;
	
	@Override
	public List<T_Goods> list(T_Goods goods, T_Criteria cri) {
		return goodsDAO.list(goods, cri);
	}
	
	
	public int total(T_Goods goods) {
		int result = goodsDAO.total(goods);
		return result;
	}

	@Override
	public T_Goods detail(T_Goods goods) {
		return this.goodsDAO.detail(goods);
	}
}
