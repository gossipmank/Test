package kr.co.OTZang.item.goods.admin;

import java.util.List;

public interface C_GoodsService {
	
	public List<C_GoodsDTO> getlist(C_GoodsDTO dto);
//	public C_GoodsDTO info(String g_code);

//	public String update(C_GoodsDTO dto);
	public void delete(String g_code);
	public void insert(C_GoodsDTO dto);
}
