package kr.co.OTZang.item.cart;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;




@Repository
public class K_CartDAO {
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public List<K_Cart> getCartList(){
		
		return this.sqlSessionTemplate.selectList("cart.cartlist");
	}
	public int deleteCart(String c_code){
		
		return this.sqlSessionTemplate.delete("cart.cartdelete", c_code);  
	}
	
	public int updateCart(int c_count,int c_code){
		K_Cart cart = new K_Cart();
		System.out.println(c_code);
		System.out.println(c_count);
		cart.setC_code(c_code);
		cart.setC_count(c_count);
		return this.sqlSessionTemplate.update("cart.cartupdate", cart);  
	}
	
	public int insertCart(K_Cart cart) {
		
		return this.sqlSessionTemplate.update("cart.cartinsert", cart);  
	}
	
		
	
	/*public List<K_Cart> getCartList(@RequestParam String c_uid){
	
	return this.sqlSessionTemplate.selectList("cart.cartlist", c_uid);*/
	

		

}



