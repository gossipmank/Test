package kr.co.OTZang.item.goods.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class C_GoodsServiceImpl implements C_GoodsService {
	 
	@Autowired
	 C_GoodsDAO goodsDao;
	 
	@Override
	 public List<C_GoodsDTO> getlist(C_GoodsDTO dto) {
		 return this.goodsDao.getList(dto);
	 }
	 
	 @Override
	 public void delete(String g_code) {
		 goodsDao.delete(g_code);
	 }
	 
	 @Override
	 public void insert(C_GoodsDTO dto) {
		 goodsDao.insert(dto);
	 }
}
