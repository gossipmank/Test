package kr.co.OTZang.item.goods.client;

import java.util.Date;

public class T_Goods {
	
	private String g_code;
	private String g_name;
	private String g_cate;
	private int g_price;
	private String g_img1;
	private String g_img2;
	private String g_detail;
	private Date g_date;
	private String g_brand;
	
	public String getG_code() {
		return g_code;
	}
	public void setG_code(String g_code) {
		this.g_code = g_code;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		this.g_name = g_name;
	}
	public String getG_cate() {
		return g_cate;
	}
	public void setG_cate(String g_cate) {
		this.g_cate = g_cate;
	}
	public int getG_price() {
		return g_price;
	}
	public void setG_price(int g_price) {
		this.g_price = g_price;
	}
	public String getG_img1() {
		return g_img1;
	}
	public void setG_img1(String g_img1) {
		this.g_img1 = g_img1;
	}
	public String getG_img2() {
		return g_img2;
	}
	public void setG_img2(String g_img2) {
		this.g_img2 = g_img2;
	}
	public String getG_detail() {
		return g_detail;
	}
	public void setG_detail(String g_detail) {
		this.g_detail = g_detail;
	}
	public Date getG_date() {
		return g_date;
	}
	public void setG_date(Date g_date) {
		this.g_date = g_date;
	}
	public String getG_brand() {
		return g_brand;
	}
	public void setG_brand(String g_brand) {
		this.g_brand = g_brand;
	}
	
	@Override
	public String toString() {
		return "T_Goods [g_code=" + g_code + ", g_name=" + g_name + ", g_cate=" + g_cate + ", g_price=" + g_price
				+ ", g_img1=" + g_img1 + ", g_img2=" + g_img2 + ", g_detail=" + g_detail + ", g_date=" + g_date
				+ ", g_mstore=" + g_brand + "]";
	}

}