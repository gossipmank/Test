package kr.co.OTZang.item.cart;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;




@Controller
public class K_Controller {
	@Autowired
	private CartService cartService;
	
	@RequestMapping("/cart/cartList.oz")
	public String getCartList(Model model) throws Exception {
		List<K_Cart> list = this.cartService.getCartList();
		model.addAttribute("cartList", list);
		return "item/cart/cartList";
	}

	@RequestMapping(value="/cart/cartDelete.oz", method = RequestMethod.POST)
	public String cartDelete(@RequestParam String c_code) throws Exception {

		cartService.deleteCart(c_code);
		return "redirect:/cart/cartList.oz";
	}

	
	
	@RequestMapping(value = "/cart/cartAllDelete.oz",  method = RequestMethod.POST)
    public String ajaxTest(HttpServletRequest request) throws Exception { 
		
		
		String[] ajaxMsg = request.getParameterValues("valueArr");
		int size = ajaxMsg.length;
		for(int i=0; i<size; i++) {
			cartService.deleteCart(ajaxMsg[i]);
		}
		return "redirect:/cart/cartList.oz";
		}
	
	@RequestMapping(value="/cart/cartUpdate.oz")
	public String cartUpdate(@RequestParam int c_count,@RequestParam int c_code) throws Exception {
		cartService.updateCart(c_count,c_code);
		return "redirect:/cart/cartList.oz";
	}
	
	@RequestMapping(value = "/cart/cartInsert.oz", method = RequestMethod.POST)
	public void cartInsert(K_Cart cart) throws Exception {
		
	 
	 //MemberVO member = (MemberVO)session.getAttribute("member");
	 //cart.setUserId(member.getUserId());

	 cartService.insertCart(cart);
	 
	}
	
}
	
/*@RequestMapping("/cart/cartList.oz")
public String getCartList(Model model,@RequestParam String c_uid) throws Exception {
	List<K_Cart> list = this.cartService.getCartList(c_uid);
	model.addAttribute("cartList", list);
	System.out.println(list);
	return "item/cart/cartList";
}
}*/

	/*@RequestMapping("/cart/cartList")
	public String getCartList(Model model) {
		K_CartDAO dao = sqlSessionTemplate.getMapper(K_CartDAO.class);
		List<K_Cart> list = dao.list();
		model.addAttribute("cartList", list);
		return "cart/cartList";
	}
	
	@RequestMapping(value="/cart/cartInsertForm", method = RequestMethod.GET)
	public String cartInsertForm(K_Cart cart) {
		return "cart/cartInsertForm";
	}
	@RequestMapping(value="/cart/cartInsert.oz", method = RequestMethod.POST)
	public String cartInsert(K_Cart cart) {
		K_CartDAO dao = sqlSessionTemplate.getMapper(K_CartDAO.class);
		int n = dao.insert(cart);
		return "redirect:/cart/cartList";
	}
	@RequestMapping("/cart/cartDelete")
	public String cartDelete(@RequestParam String c_code) {
		K_CartDAO dao = sqlSessionTemplate.getMapper(K_CartDAO.class);
			String n = dao.delete(c_code);
			return "redirect:/cart/cartList";
	}	
}*/
