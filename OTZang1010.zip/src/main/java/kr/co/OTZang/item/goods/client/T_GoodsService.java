package kr.co.OTZang.item.goods.client;

import java.util.List;

public interface T_GoodsService {
	
	List<T_Goods> list(T_Goods goods, T_Criteria cri);
	
	int total(T_Goods goods);
	
	T_Goods detail(T_Goods goods);

}
