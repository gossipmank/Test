package kr.co.OTZang.item.goods.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class T_GoodsController {
		@Autowired
		T_GoodsService goodsService;
		T_GoodsDAO goodsDAO;
		
		// 리스트
		@RequestMapping("/Cgoods/list.oz")
		public String getGoodsList(T_Goods goods, Model model, T_Criteria cri) {
			
			int total = goodsService.total(goods);
			model.addAttribute("goodsPage", new T_GoodsPage(cri, total));
			model.addAttribute("goodsList", goodsService.list(goods, cri));
			
			return "/item/goods/client/goodsList";
		} 
		
		// 상세 조회
		@RequestMapping(value="/Cgoods/detail.oz")
		public ModelAndView detail(T_Goods goods) {
		    T_Goods detailGoods = this.goodsService.detail(goods);
		    ModelAndView mav = new ModelAndView();
		    mav.addObject("goodsDetail", detailGoods);
		    String goodsCode = goods.getG_code().toString();
		    mav.addObject("g_code", goodsCode);
		    mav.setViewName("/item/goods/client/goodsDetail");
		    return mav;
		}
		
		// 주문
		@RequestMapping(value="/Cgoods/order.oz")
		public String goodsPay(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html; charset=UTF-8");
			request.setCharacterEncoding("UTF-8");
			return "/payment/J_PayPage";
			
		}
		
		// 결제 성공창
		@RequestMapping(value="/success.oz")
		public String goodsSuccess() {
			
			/*
			 * HttpRequest request = HttpRequest.newBuilder() .uri(URI.create(
			 * "https://api.tosspayments.com/v1/payments/69hxBol10aciiBJTBOnqX"))
			 * .header("Authorization",
			 * "Basic dGVzdF9za196WExrS0V5cE5BcldtbzUwblgzbG1lYXhZRzVSOg==") .method("GET",
			 * HttpRequest.BodyPublishers.noBody()) .build(); HttpResponse<String> response
			 * = HttpClient.newHttpClient().send(request,
			 * HttpResponse.BodyHandlers.ofString()); System.out.println(response.body());
			 */
			
			
			return "/item/goods/client/success";
			
		}
		
		
		
		
}