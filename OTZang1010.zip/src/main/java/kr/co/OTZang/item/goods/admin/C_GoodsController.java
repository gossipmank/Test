package kr.co.OTZang.item.goods.admin;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
public class C_GoodsController {
	@Autowired
	C_GoodsService goodsService;
	
	C_GoodsDTO dto = new C_GoodsDTO();
	
	@RequestMapping(value="/Agoods/list")		// 상품리스트 띄우기
	public String getGoodsList(Model model) {
		List<C_GoodsDTO> list = this.goodsService.getlist(dto);
		model.addAttribute("goodsList", list);
		System.out.println(list);
		return "item/goods/C_goodsList";
	}
	
	
//	@RequestMapping(value="/Agoods/del", method = RequestMethod.GET)
//	public String goodsDelete(@RequestParam String g_code) throws Exception {
//		
//		System.out.println((String)g_code);	
//		goodsService.delete(g_code);
//		return "item/goods/C_goodsList";
//	}
	
	@RequestMapping(value = "/Agoods/del")		//goods 선택삭제
    public String ajaxTest(HttpServletRequest request) throws Exception {
    
		String[] ajaxMsg = request.getParameterValues("valueArr");
		int size = ajaxMsg.length;
		for(int i=0; i<size; i++) {
			goodsService.delete(ajaxMsg[i]);
		}
		return "item/goods/C_goodsList";
		}
	
    @RequestMapping(value="/Agoods/ins", method = RequestMethod.GET)
    public String getInert()  {
    	System.out.println("상품등록 view페이지");
        return "item/goods/C_goodsInsert";
    }


}
