package kr.co.OTZang.item.goods.client;

public class T_GoodsPage {

	private int startPage;
	private int endPage;
	private boolean prev, next;
	
	private int total;
	//현재 페이지 번호, 한 페이지에 표출할 데이터 개수
	private T_Criteria cri;
	
	public T_GoodsPage(T_Criteria cri, int total) {
		this.cri = cri;
		this.total = total;
		
		//시작페이지, 마지막페이지 계산
		this.endPage = (int)(Math.ceil(cri.getPageNum() / 10.0)) * 10;
		this.startPage = this.endPage -9;
		
		int realEnd = (int) (Math.ceil(total * 1.0) / cri.getAmount());
		
		if(realEnd < this.endPage) {
			this.endPage = realEnd;
		}
		
		//이전, 다음 버튼 표출 여부 결정
		this.prev = this.startPage > 1;
		this.next = this.endPage < realEnd;
	}
	
	public int getStartPage() {
		return startPage;
	}
	public int getEndPage() {
		return endPage;
	}
	public boolean isPrev() {
		return prev;
	}
	public boolean isNext() {
		return next;
	}
	public int getTotal() {
		return total;
	}
	public T_Criteria getCri() {
		return cri;
	}

	@Override
	public String toString() {
		return "T_GoodsPage [startPage=" + startPage + ", endPage=" + endPage + ", prev=" + prev + ", next=" + next
				+ ", total=" + total + "]";
	}
}
