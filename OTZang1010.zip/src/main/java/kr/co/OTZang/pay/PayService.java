package kr.co.OTZang.pay;

import java.util.List;

import kr.co.OTZang.user.admin.User;

public interface PayService {
	
	public boolean inPaybackup(PayBackup paybackup);

	public boolean inPay(Pay pay);

	public List<PayBackup> payBackupList(String p_code);

	public Pay payinfo(String p_code);

}
