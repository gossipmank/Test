package kr.co.OTZang.pay;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PayDAO {
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;

	public int inPaybackup(PayBackup paybackup) {
		return this.sqlSessionTemplate.insert("pay.insertPayBackup", paybackup);  
	}

	public int inPay(Pay pay) {
		return this.sqlSessionTemplate.insert("pay.insertPay", pay);
	}

	public List<PayBackup> payBackupList(String p_code) {
		return this.sqlSessionTemplate.selectList("pay.payBackupList",p_code);
	}

	public Pay payinfo(String p_code) {
		return this.sqlSessionTemplate.selectOne("pay.payinfo",p_code);
	}

}
