package kr.co.OTZang.pay;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.OTZang.user.admin.MuserDAO;

@Service
public class PayServiceImpl implements PayService {
	
	@Autowired
	PayDAO payDao;

	@Override
	public boolean inPaybackup(PayBackup paybackup) {
		int affectRowCount = this.payDao.inPaybackup(paybackup);  
		return affectRowCount == 1; 
	}

	@Override
	public boolean inPay(Pay pay) {
		int affectRowCount = this.payDao.inPay(pay);  
		return affectRowCount == 1; 
		
	}

	@Override
	public List<PayBackup> payBackupList(String p_code) {
		// TODO Auto-generated method stub
		return this.payDao.payBackupList(p_code);
	}

	@Override
	public Pay payinfo(String p_code) {
		return this.payDao.payinfo(p_code);
	}

}
