package kr.co.OTZang.pay;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.OTZang.item.cart.CartService;
import kr.co.OTZang.item.cart.K_Cart;
import kr.co.OTZang.user.admin.AdminService;
import kr.co.OTZang.user.admin.User;
import kr.co.OTZang.user.dto.UserDTO;
import kr.co.OTZang.user.service.UserService;

@Controller
public class PayController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private PayService payService;
	@Autowired
	private CartService cartService;
	
		
		@RequestMapping(value = "/C_pay/success.oz", method = RequestMethod.POST)
		public String paySuccess(Model model,HttpServletRequest re) throws Exception {
			String p_code = re.getParameter("p_code");
			String gcode = re.getParameter("p_gcode2");
			String[] gcode2 = gcode.split(",");
			String gname = re.getParameter("p_gname2");
			String[] gname2 = gname.split(",");
			String gbrand = re.getParameter("p_gbrand2");
			String[] gbrand2 = gbrand.split(",");
			String gcate = re.getParameter("p_gcate2");
			String[] gcate2 = gcate.split(",");
			String gprice = re.getParameter("p_gprice2");
			String[] gprice2 = gprice.split(",");
			String gimg = re.getParameter("p_gimg2");
			String[] gimg2 = gimg.split(",");
			String goption = re.getParameter("p_goption2");
			String[] goption2 = goption.split(",");
			String gcount = re.getParameter("p_gcount2");
			String[] gcount2 = gcount.split(",");
			int point = gcode2.length;
			for (int i = 0; i < point; i++) {
				PayBackup paybackup = new PayBackup();
				paybackup.setP_code(p_code);
				paybackup.setP_gcode(gcode2[i]);
				paybackup.setP_gname(gname2[i]);
				paybackup.setP_gbrand(gbrand2[i]);
				paybackup.setP_gcate(gcate2[i]);
				paybackup.setP_gprice(Integer.parseInt(gprice2[i]));
				paybackup.setP_gimg(gimg2[i]);
				paybackup.setP_goption(goption2[i]);
				paybackup.setP_gcount(Integer.parseInt(gcount2[i]));
				this.payService.inPaybackup(paybackup);
			}
			
			Pay pay = new Pay();
			pay.setP_code(p_code);
			pay.setP_uid(re.getParameter("p_uid"));
			pay.setP_uname(re.getParameter("p_uname"));
			pay.setP_name(re.getParameter("p_name"));
			pay.setP_add1(re.getParameter("p_add1"));
			pay.setP_add2(re.getParameter("p_add2"));
			pay.setP_add3(re.getParameter("p_add3"));
			pay.setP_tel(re.getParameter("p_tel"));
			pay.setP_message(re.getParameter("p_message"));
			pay.setP_total(Integer.parseInt(re.getParameter("p_total").replaceAll("[^0-9]", "")));
			pay.setP_condition(re.getParameter("p_condition"));
			
			boolean isDeleteSuccess = this.payService.inPay(pay);
			if (isDeleteSuccess) {  
				
				List<PayBackup> paybackup2 = this.payService.payBackupList(p_code);
				model.addAttribute("paybackup",paybackup2);
				
				Pay pay2 = this.payService.payinfo(p_code);
				model.addAttribute("pay", pay2);
				
				re.setAttribute("p_code", p_code);
				return "payment/J_PaySuccess";
			}else {  
				model.addAttribute("msg","결제가 실패했습니다.");
				model.addAttribute("url","/C_pay/fail.oz");
				return "user/admin/account/J_alert"; 
			}
			}
		
		@RequestMapping("/C_pay/fail.oz")
		public String payFail(Model model,HttpServletRequest re) {
	            return "payment/J_PayFail";
			}
		
		@RequestMapping("/C_pay/cancel.oz")
		public String payCancel(Model model,HttpServletRequest re) {
	            return "payment/J_PayCancel";
			}
		
		@RequestMapping("/C_pay/payment.oz")
		public String payment(Model model,HttpSession session) throws Exception{
			try {
				String u_id = (String)session.getAttribute("u_id");
				UserDTO user = this.userService.info(u_id);
				if(user != null) {
				model.addAttribute("pay_info", user);
				List<K_Cart> list = this.cartService.getCartList();
				model.addAttribute("cartList", list);
				return "payment/J_PayPage";
				}
				else {
					model.addAttribute("msg","로그인이 필요합니다.");
		            model.addAttribute("url","/client/Login.oz");
		            return "user/admin/account/J_alert";
				}

			} catch (Exception e) {
				model.addAttribute("msg","정보를 불러올 수 없습니다.");
	            model.addAttribute("url","/main.oz");
	            return "user/admin/account/J_alert";
			}
	            
		}
		
}
