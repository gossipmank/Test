package kr.co.OTZang.pay;

public class PayBackup {
	private String p_code;
	private String p_gcode;
	private String p_gname;
	private String p_gbrand;
	private String p_gcate;
	private int p_gprice;
	private String p_gimg;
	private String p_goption;
	private int p_gcount;
	public String getP_code() {
		return p_code;
	}
	public void setP_code(String p_code) {
		this.p_code = p_code;
	}
	public String getP_gcode() {
		return p_gcode;
	}
	public void setP_gcode(String p_gcode) {
		this.p_gcode = p_gcode;
	}
	public String getP_gname() {
		return p_gname;
	}
	public void setP_gname(String p_gname) {
		this.p_gname = p_gname;
	}
	public String getP_gbrand() {
		return p_gbrand;
	}
	public void setP_gbrand(String p_gbrand) {
		this.p_gbrand = p_gbrand;
	}
	public String getP_gcate() {
		return p_gcate;
	}
	public void setP_gcate(String p_gcate) {
		this.p_gcate = p_gcate;
	}
	public int getP_gprice() {
		return p_gprice;
	}
	public void setP_gprice(int p_gprice) {
		this.p_gprice = p_gprice;
	}
	public String getP_gimg() {
		return p_gimg;
	}
	public void setP_gimg(String p_gimg) {
		this.p_gimg = p_gimg;
	}
	public String getP_goption() {
		return p_goption;
	}
	public void setP_goption(String p_goption) {
		this.p_goption = p_goption;
	}
	public int getP_gcount() {
		return p_gcount;
	}
	public void setP_gcount(int p_gcount) {
		this.p_gcount = p_gcount;
	}
	@Override
	public String toString() {
		return "PayBackup [p_code=" + p_code + ", p_gcode=" + p_gcode + ", p_gname=" + p_gname + ", p_gbrand="
				+ p_gbrand + ", p_gcate=" + p_gcate + ", p_gprice=" + p_gprice + ", p_gimg=" + p_gimg + ", p_goption="
				+ p_goption + ", p_gcount=" + p_gcount + "]";
	}
	public PayBackup(String p_code, String p_gcode, String p_gname, String p_gbrand, String p_gcate, int p_gprice,
			String p_gimg, String p_goption, int p_gcount) {
		super();
		this.p_code = p_code;
		this.p_gcode = p_gcode;
		this.p_gname = p_gname;
		this.p_gbrand = p_gbrand;
		this.p_gcate = p_gcate;
		this.p_gprice = p_gprice;
		this.p_gimg = p_gimg;
		this.p_goption = p_goption;
		this.p_gcount = p_gcount;
	}
	public PayBackup() {
	}
	
	

}
