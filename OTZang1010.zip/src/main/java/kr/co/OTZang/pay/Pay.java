package kr.co.OTZang.pay;

import java.util.Date;

public class Pay {
	private String p_code;
	private String p_uid;
	private String p_uname;
	private String p_name;
	private String p_add1;
	private String p_add2;
	private String p_add3;
	private String p_tel;
	private String p_message;
	private int p_total;
	private String p_condition;
	private Date p_date;
	
	public String getP_code() {
		return p_code;
	}
	public void setP_code(String p_code) {
		this.p_code = p_code;
	}

	public String getP_uid() {
		return p_uid;
	}
	public void setP_uid(String p_uid) {
		this.p_uid = p_uid;
	}
	public String getP_uname() {
		return p_uname;
	}
	public void setP_uname(String p_uname) {
		this.p_uname = p_uname;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_add1() {
		return p_add1;
	}
	public void setP_add1(String p_add1) {
		this.p_add1 = p_add1;
	}
	public String getP_add2() {
		return p_add2;
	}
	public void setP_add2(String p_add2) {
		this.p_add2 = p_add2;
	}
	public String getP_add3() {
		return p_add3;
	}
	public void setP_add3(String p_add3) {
		this.p_add3 = p_add3;
	}
	public String getP_tel() {
		return p_tel;
	}
	public void setP_tel(String p_tel) {
		this.p_tel = p_tel;
	}
	public String getP_message() {
		return p_message;
	}
	public void setP_message(String p_message) {
		this.p_message = p_message;
	}
	public int getP_total() {
		return p_total;
	}
	public void setP_total(int p_total) {
		this.p_total = p_total;
	}
	public String getP_condition() {
		return p_condition;
	}
	public void setP_condition(String p_condition) {
		this.p_condition = p_condition;
	}
	public Date getP_date() {
		return p_date;
	}
	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}
	
	

	@Override
	public String toString() {
		return "Pay [p_code=" + p_code + ", p_uid=" + p_uid + ", p_uname=" + p_uname + ", p_name=" + p_name
				+ ", p_add1=" + p_add1 + ", p_add2=" + p_add2 + ", p_add3=" + p_add3 + ", p_tel=" + p_tel
				+ ", p_message=" + p_message + ", p_total=" + p_total + ", p_condition=" + p_condition + ", p_date="
				+ p_date + "]";
	}
	public Pay(String p_code, String p_gcode, String p_gname, String p_gbrand, String p_gcate, int p_gprice,
			String p_gimg, String p_goption, int p_gcount, String p_uid, String p_uname, String p_name, String p_add1,
			String p_add2, String p_add3, String p_tel, String p_message, int p_total, String p_condition,
			Date p_date) {
		super();
		this.p_code = p_code;
		this.p_uid = p_uid;
		this.p_uname = p_uname;
		this.p_name = p_name;
		this.p_add1 = p_add1;
		this.p_add2 = p_add2;
		this.p_add3 = p_add3;
		this.p_tel = p_tel;
		this.p_message = p_message;
		this.p_total = p_total;
		this.p_condition = p_condition;
		this.p_date = p_date;
	}
	public Pay() {}
	
	

}
