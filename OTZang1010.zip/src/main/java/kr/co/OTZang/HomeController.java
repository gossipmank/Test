package kr.co.OTZang;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.OTZang.user.dto.UserDTO;
import kr.co.OTZang.user.service.UserService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Inject
	private UserService service;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Model model) {
		return "index";
	}
	@RequestMapping(value = "/main.oz", method = RequestMethod.GET)
	public String index2(Model model) {
		return "index";
	}
	@RequestMapping(value = "/admin.oz")
	public String adminindex(Model model,HttpServletRequest re) throws Exception{
		try {
			HttpSession session=re.getSession();
			String id=(String)session.getAttribute("m_id");
			if(!id.equals(null)) {
				return "user/admin/adminIndex";
			}
		} catch (Exception e) {
			return "user/admin/account/J_login";
		}
		return null;
	}
	
	@RequestMapping(value = "/join.oz", method = RequestMethod.GET)
	public String home2(Locale locale, Model model) throws Exception{
		logger.info("home");
		List<UserDTO> memberList = service.selectMember();
		model.addAttribute("memberList", memberList);
		return "user/client/ujoin";
	}

	@RequestMapping(value = "/login.oz", method = RequestMethod.GET)
	public String home3(Locale locale, Model model) throws Exception{
		logger.info("home");
		List<UserDTO> memberList = service.selectMember();
		model.addAttribute("memberList", memberList);
		return "common/LoginPage";
	}
	
	@RequestMapping(value = "/myinfo.oz", method = RequestMethod.GET)
	public String home4(Locale locale, Model model) throws Exception{
		logger.info("home");
		List<UserDTO> memberList = service.selectMember();
		model.addAttribute("memberList", memberList);
		return "user/client/umyinfo";
	}
	
	@RequestMapping(value="logout.oz", method=RequestMethod.GET)
    public String logoutMainGET(HttpServletRequest request) throws Exception{        
        logger.info("logoutMainGET메서드 진입");       
        HttpSession session = request.getSession();        
        session.invalidate();        
        return "redirect:/";               
    }
	
	@RequestMapping(value = "/delete.oz", method = RequestMethod.GET)
	public String home5(Locale locale, Model model) throws Exception{
		logger.info("home");
		List<UserDTO> memberList = service.selectMember();
		model.addAttribute("memberList", memberList);
		return "user/client/udelete";
	}
	
}
