package kr.co.OTZang.user.admin;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	
	@RequestMapping("/admin/login.oz")
	public String adminlogin(Model model,HttpServletRequest re,@RequestParam String m_id,@RequestParam String m_pwd) throws Exception{
		User muser = this.adminService.login(m_id,m_pwd);
		try {
			model.addAttribute("muser",muser);
			HttpSession session=re.getSession();
			session.setAttribute("m_id", muser.getU_id());
			session.setAttribute("m_name", muser.getU_name());
			return "/user/admin/adminIndex";
		}catch (Exception e) {
			model.addAttribute("msg","아이디나 비밀번호가 일치하지 않습니다.");
            model.addAttribute("url","/admin.oz");
            return "user/admin/account/J_alert";
		}
	}
	
	@RequestMapping("/admin/logout.oz")
	public String adminlogout(Model model,HttpServletRequest re) throws Exception {
		HttpSession session=re.getSession();
		session.invalidate();
		model.addAttribute("msg","로그아웃 되었습니다.");
        model.addAttribute("url","/admin.oz");
        return "user/admin/account/J_alert";
		
	}
	
	@RequestMapping("/admin/myInfo.oz")
	public String myInfo(Model model,HttpServletRequest re) {
		HttpSession session=re.getSession();
		String id=(String)session.getAttribute("m_id");
		User muser = this.adminService.info(id);
		model.addAttribute("info", muser);
		return "user/admin/account/J_myInfo";
	}
	
	@RequestMapping(value = "/admain/myUpdate.oz", method = RequestMethod.GET)
	public String getMyUpdate(Model model,HttpServletRequest re) {
		HttpSession session=re.getSession();
		String id=(String)session.getAttribute("m_id");
		User muser = this.adminService.info(id);
		model.addAttribute("info", muser);
		return "user/admin/account/J_myUpdate";
	}
	
	@RequestMapping(value = "/admin/myUpdate.oz",method = RequestMethod.POST)
	public String PostMyUpdate(Model model, HttpServletRequest re,User muser) throws Exception {
		muser.setU_id((String)re.getParameter("m_id"));
		muser.setU_name((String)re.getParameter("m_name"));
		muser.setU_birth((String)re.getParameter("m_birth"));
		muser.setU_gen((String)re.getParameter("m_gen"));
		muser.setU_code((String)re.getParameter("m_code"));
		muser.setU_add1((String)re.getParameter("m_add1"));
		muser.setU_add2((String)re.getParameter("m_add2"));
		muser.setU_tel((String)re.getParameter("m_tel"));
		muser.setU_ok((String)re.getParameter("m_ok"));
		
		boolean isUpdateSuccess = this.adminService.myUpdate(muser);
		if (isUpdateSuccess) {
			model.addAttribute("msg","수정이 성공했습니다.");
	        model.addAttribute("url","/admin/myInfo.oz");
	        return "user/admin/account/J_alert";
		}else { 
			model.addAttribute("msg","수정이 실패했습니다.");
	        model.addAttribute("url","/admain/myUpdate.oz");
	        return "user/admin/account/J_alert";
		}  
	}
	
	@RequestMapping(value = "/admin/pwdUpdate.oz",method = RequestMethod.GET)
	public String pwdUpdate(Model model,HttpServletRequest re) {
		return "user/admin/account/J_passUpdate";
	}
	
	@RequestMapping(value = "/admin/pwdUpdate.oz",method = RequestMethod.POST)
	public String pwdUpdate(Model model,HttpServletRequest re,@RequestParam String m_pwdup) {
		HttpSession session=re.getSession();
		String id=(String)session.getAttribute("m_id");
		boolean isUpdateSuccess = this.adminService.passUp(id,m_pwdup);
		if (isUpdateSuccess) {
			model.addAttribute("msg","수정이 성공했습니다.");
	        model.addAttribute("url","/admin.oz");
	        return "user/admin/account/J_alert";
		}else { 
			model.addAttribute("msg","수정이 실패했습니다.");
	        model.addAttribute("url","/admin/pwdUpdate.oz");
	        return "user/admin/account/J_alert";
		}  
	}
	
	@RequestMapping(value = "/passUpdateCheck.oz")
	@ResponseBody
	public void passCheck(Model model,HttpServletRequest req,HttpServletResponse res) throws Exception {
		HttpSession session=req.getSession();
		String pw = req.getParameter("m_pwd");
		String id = (String)session.getAttribute("m_id");
		int result = 2;
		try {
			User muser = this.adminService.passUpdate(id,pw);
			 if (!muser.getU_id().equals(null)) { result = 0;
		     } else { if (pw.length() == 0) { result = 1;  } else { result = 2; }
		     }
		} catch (Exception e) {
		}
		finally {
			PrintWriter out = res.getWriter();
			out.write(result + "");
		}
	}
	
	@RequestMapping(value = "/admin/muserList.oz", method = RequestMethod.GET)
	public String getEmpList(Model model) {
		List<User> muserlist = this.adminService.muserList();
		model.addAttribute("muserList",muserlist);
		return "user/admin/muser/J_muserList";
	}
	
	@RequestMapping(value = "/admin/muserList.oz", method = RequestMethod.POST)
	public String getEmpList(Model model,@RequestParam String keyword,@RequestParam String search) {
		List<User> muserlist = this.adminService.muserKeyList(keyword,search);
		model.addAttribute("muserList",muserlist);
		return "user/admin/muser/J_muserList";
	}

	@RequestMapping("/admin/muserDetail/{m_id}")
	public String page(Model model,@PathVariable String m_id) {
		User muser = this.adminService.info(m_id);
		model.addAttribute("mu_info", muser);
		return "user/admin/muser/J_muserDetail";	
	}
	
	@RequestMapping(value = "/admin/muserUpdate/{m_id}", method = RequestMethod.GET)
	public String getMuserUpdate(Model model,HttpServletRequest re,@PathVariable String m_id) {
		User muser = this.adminService.info(m_id);
		model.addAttribute("mu_info", muser);
		return "user/admin/muser/J_muserUpdate";
	}
	
	@RequestMapping(value = "/admin/muserUpdate/{m_id}",method = RequestMethod.POST)
	public String PostMuserUpdate(Model model, HttpServletRequest re,User muser,@PathVariable String m_id) throws Exception {
		muser.setU_id(m_id);
		muser.setU_name((String)re.getParameter("m_name"));
		muser.setU_birth((String)re.getParameter("m_birth"));
		muser.setU_gen((String)re.getParameter("m_gen"));
		muser.setU_code((String)re.getParameter("m_code"));
		muser.setU_add1((String)re.getParameter("m_add1"));
		muser.setU_add2((String)re.getParameter("m_add2"));
		muser.setU_tel((String)re.getParameter("m_tel"));
		muser.setU_ok((String)re.getParameter("m_ok"));
		
		boolean isUpdateSuccess = this.adminService.myUpdate(muser);
		if (isUpdateSuccess) {
			model.addAttribute("msg","수정이 성공했습니다.");
	        model.addAttribute("url","/admin/muserDetail/"+m_id);
	        return "user/admin/account/J_alert";
		}else { 
			model.addAttribute("msg","수정이 실패했습니다.");
	        model.addAttribute("url","/admin/muserUpdate/"+m_id);
	        return "user/admin/account/J_alert";
		}  
	}
	
	@RequestMapping(value = "/admin/muserDelete/{m_id}", method = RequestMethod.GET)
	public String getMuserDelete(Model model,HttpServletRequest re,@PathVariable String m_id) {
		model.addAttribute("m_id", m_id);
		return "user/admin/muser/J_muserDelete";
	}
	
	@RequestMapping(value = "/admin/muserDelete/{m_id}", method = RequestMethod.POST)  
	public String postMuserDelete(Model model,@PathVariable String m_id) {   

		boolean isDeleteSuccess = this.adminService.muserDelete(m_id);  
			if (isDeleteSuccess) {  
				model.addAttribute("msg","탈퇴가 완료되었습니다.");
				model.addAttribute("url","/admin/muserList.oz");
				return "user/admin/account/J_alert"; 
			}else {  
				model.addAttribute("msg","탈퇴가 실패했습니다.");
				model.addAttribute("url","/admin/muserDelete/"+m_id);
				return "user/admin/account/J_alert"; 
			}
	}  
	
}
