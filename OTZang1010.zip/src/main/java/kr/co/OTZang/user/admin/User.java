package kr.co.OTZang.user.admin;

public class User {
	private String u_id;
	private String u_pwd;
	private String u_name;
	private String u_file;
	private String u_tel;
	private String u_birth;
	private String u_gen;
	private String u_code;
	private String u_add1;
	private String u_add2;
	private String u_ok;
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pwd() {
		return u_pwd;
	}
	public void setU_pwd(String u_pwd) {
		this.u_pwd = u_pwd;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_file() {
		return u_file;
	}
	public void setU_file(String u_file) {
		this.u_file = u_file;
	}
	public String getU_tel() {
		return u_tel;
	}
	public void setU_tel(String u_tel) {
		this.u_tel = u_tel;
	}
	public String getU_birth() {
		return u_birth;
	}
	public void setU_birth(String u_birth) {
		this.u_birth = u_birth;
	}
	public String getU_gen() {
		return u_gen;
	}
	public void setU_gen(String u_gen) {
		this.u_gen = u_gen;
	}
	public String getU_code() {
		return u_code;
	}
	public void setU_code(String u_code) {
		this.u_code = u_code;
	}
	public String getU_add1() {
		return u_add1;
	}
	public void setU_add1(String u_add1) {
		this.u_add1 = u_add1;
	}
	public String getU_add2() {
		return u_add2;
	}
	public void setU_add2(String u_add2) {
		this.u_add2 = u_add2;
	}
	public String getU_ok() {
		return u_ok;
	}
	public void setU_ok(String u_ok) {
		this.u_ok = u_ok;
	}
	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", u_pwd=" + u_pwd + ", u_name=" + u_name + ", u_file=" + u_file + ", u_tel="
				+ u_tel + ", u_birth=" + u_birth + ", u_gen=" + u_gen + ", u_code=" + u_code + ", u_add1=" + u_add1
				+ ", u_add2=" + u_add2 + ", u_ok=" + u_ok + "]";
	}
	public User(String u_id, String u_pwd, String u_name, String u_file, String u_tel, String u_birth, String u_gen,
			String u_code, String u_add1, String u_add2, String u_ok) {
		super();
		this.u_id = u_id;
		this.u_pwd = u_pwd;
		this.u_name = u_name;
		this.u_file = u_file;
		this.u_tel = u_tel;
		this.u_birth = u_birth;
		this.u_gen = u_gen;
		this.u_code = u_code;
		this.u_add1 = u_add1;
		this.u_add2 = u_add2;
		this.u_ok = u_ok;
	}
	public User() {
	}
	
	
	

}
