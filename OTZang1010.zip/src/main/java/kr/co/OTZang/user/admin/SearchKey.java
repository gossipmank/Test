package kr.co.OTZang.user.admin;

public class SearchKey {
	private String keyword;
	private String search;
	
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	@Override
	public String toString() {
		return "SearchKey [keyword=" + keyword + ", search=" + search + "]";
	}
	public SearchKey(String keyword, String search) {
		super();
		this.keyword = keyword;
		this.search = search;
	}
	public SearchKey() {
	}
	
	

}
