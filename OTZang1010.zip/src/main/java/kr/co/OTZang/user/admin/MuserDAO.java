package kr.co.OTZang.user.admin;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

@Repository
public class MuserDAO {
	
	@Autowired
	SqlSessionTemplate sqlSessionTemplate;
	
	public User login(@RequestParam String m_id,@RequestParam String m_pwd) {
		User muser = new User();
		muser.setU_id(m_id);
		muser.setU_pwd(m_pwd);
		return this.sqlSessionTemplate.selectOne("muser.login",muser);
	}
	
	public User info(String m_id) {
		return this.sqlSessionTemplate.selectOne("muser.info",m_id);
		
	}
	
	public int myInfoUpdate(User muser) {  
		return this.sqlSessionTemplate.update("muser.myupdate", muser);  
		}  
	
	public User passUpdate(String m_id,String m_pwd) {
		User muser = new User();
		muser.setU_id(m_id);
		muser.setU_pwd(m_pwd);
		return this.sqlSessionTemplate.selectOne("muser.login",muser);
	}

	public int passUp(String m_id, String m_pwdup) {  
		User muser = new User();
		muser.setU_id(m_id);
		muser.setU_pwd(m_pwdup);
		return this.sqlSessionTemplate.update("muser.passUpdate", muser);  
		}

	public List<User> muserList() {
		return this.sqlSessionTemplate.selectList("muser.muserList");
	}

	public int muserDelete(String m_id) {
		return this.sqlSessionTemplate.delete("muser.muserDelete", m_id); 
	}

	public List<User> muserKeyList(String keyword,String search) {
		SearchKey key = new SearchKey();
		key.setKeyword(keyword);
		key.setSearch(search);
		return this.sqlSessionTemplate.selectList("muser.muserKeyList",key);
	}
	


}
