package kr.co.OTZang.user.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface AdminService {
	
	public User login(String m_id,String m_pwd);
	public User info(String m_id);
	public boolean myUpdate(User muser);
	public boolean passUp(String m_id,String m_pwdup);
	public User passUpdate(String m_id,String m_pwd);
	public List<User> muserList();
	public boolean muserDelete(String m_id);
	public List<User> muserKeyList(String keyword,String search);


}
