package kr.co.OTZang.user.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.co.OTZang.user.dto.UserDTO;

@Repository
public class UserDAO {
	@Autowired
	private SqlSessionTemplate mybatis;
	
	public int userInsert(UserDTO dto) {
		System.out.println("user DAO insert");
		int result = mybatis.insert("UserDAO.insert", dto);
		return result;
	}
	
	public UserDTO getUserInfo(String u_id) {
		System.out.println("user DAO Info");
		return (UserDTO) mybatis.selectOne("UserDAO.info", u_id);
	}
	
	public int Login(UserDTO dto) throws Exception {
        return mybatis.selectOne("UserDAO.login", dto);
 }
	
	public List<UserDTO> getUserList(UserDTO dto) {
		System.out.println("user DAO list");
		return mybatis.selectList("UserDAO.list", dto);
	}
	
	public int userDelete(String u_id) {
		System.out.println("user DAO delete");
		
		int result = mybatis.delete("UserDAO.delete", u_id);
		return result;
	}
}
