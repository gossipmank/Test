package kr.co.OTZang.user.service;

import java.util.List;

import kr.co.OTZang.user.dto.UserDTO;

public interface UserService {
	
	public List<UserDTO> selectMember() throws Exception;
	
	int insert(UserDTO dto);
	
	public int Login(UserDTO dto) throws Exception;
	
	UserDTO info(String u_id);
	
	int delete(String u_id);
}
