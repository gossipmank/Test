package kr.co.OTZang.user.admin;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	MuserDAO muserDao;

	@Override
	public User login(@RequestParam String m_id,@RequestParam String m_pwd) {
		return this.muserDao.login(m_id,m_pwd);
	}

	@Override
	public User info(String m_id) {
		return this.muserDao.info(m_id);
	}
	
	@Override
	public boolean myUpdate(User muser) {  
	int affectRowCount = this.muserDao.myInfoUpdate(muser);  
	return affectRowCount == 1; 

	}

	@Override
	public User passUpdate(String m_id, String m_pwd) {
		return this.muserDao.passUpdate(m_id,m_pwd);
	}

	@Override
	public boolean passUp(String m_id, String m_pwdup) {
		int affectRowCount = this.muserDao.passUp(m_id,m_pwdup);  
		return affectRowCount == 1; 
	}

	@Override
	public List<User> muserList() {
		return this.muserDao.muserList();
		
	}

	@Override
	public boolean muserDelete(String m_id) {
		int affectRowCount = this.muserDao.muserDelete(m_id);  
		return affectRowCount == 1; 
	}

	@Override
	public List<User> muserKeyList(String keyword,String search) {
		return this.muserDao.muserKeyList(keyword,search);
	}
	
}
