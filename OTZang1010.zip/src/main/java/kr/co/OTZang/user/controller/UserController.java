package kr.co.OTZang.user.controller;

import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.co.OTZang.user.dto.UserDTO;
import kr.co.OTZang.user.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private JavaMailSender mailSender;
	
	//회원가입 페이지 이동
	@RequestMapping(value = "/client/Join.oz", method = RequestMethod.POST)
	public String ujoin(@ModelAttribute("dto") UserDTO dto) {
		return "user/client/ujoin";
	}
	//회원가입 완료시
	@RequestMapping(value="userJoin.oz", method = RequestMethod.POST )
	public String userJoin(@ModelAttribute("UserDTO") UserDTO dto) {
		int result = userService.insert(dto);
		System.out.println(result + "개 업데이트");
			return "user/client/ujoin";
	}
	
    @RequestMapping(value = "/client/Login.oz", method = RequestMethod.GET)
    public String LoginPage() {
        return "common/LoginPage";
    }
    
    @RequestMapping(value="/Logout.oz")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

    @RequestMapping(value = "/Login.oz", method = RequestMethod.POST)
    public String Login(@RequestParam("u_id") String u_id, @RequestParam("u_pwd") String u_pwd, HttpSession session) throws Exception {
    	session.setAttribute("u_id", u_id);
        String path = "";

        UserDTO dto = new UserDTO();

        dto.setU_id(u_id);
        dto.setU_pwd(u_pwd);

        int result = userService.Login(dto);

        if(result == 1) {
            path = "index";
            System.out.println(session);
        } else {
            path = "/common/LoginPage";
        }

        return path;
    }
    
    @RequestMapping(value="/client/MyInfo.oz")
	public String umyinfo(Model model, @ModelAttribute("dto")UserDTO dto, HttpSession session) {
		String u_id = (String)session.getAttribute("u_id");
		model.addAttribute("info", userService.info(u_id));
		if(u_id != null) { 
			return "/client/umyinfo"; 
			} else return "redirect:/Login";	
	}
    
    @RequestMapping(value="/client/Delete.oz", method = RequestMethod.GET )
	public String userDeleteForm(Model model, @ModelAttribute("dto")UserDTO dto, HttpSession session) {
		String u_id = (String)session.getAttribute("u_id");
		model.addAttribute("info", userService.info(u_id));
		if(u_id != null) { 
			return "user/client/udelete";
			} else return "redirect:/Login";
	}
	
	@RequestMapping(value="/UserDelete", method = RequestMethod.POST )
	public String userDelete(String u_id, HttpSession session) {
		int result = userService.delete(u_id);
		if(result > 0) {session.invalidate();}
		System.out.println(result+"업데이트");
			return "redirect:/";
	}
	
	/* 이메일 인증 */
    @RequestMapping(value="/emailAuth", method= {RequestMethod.GET, RequestMethod.POST})
    public String mailCheckGET(String email) throws Exception{
               
        /* 인증번호(난수) 생성 */
        Random random = new Random();
        int checkNum = random.nextInt(888888) + 111111;
        System.out.println("인증번호 " + checkNum);
        
        /* 이메일 보내기 */
        String setFrom = "otz_ang@naver.com";
        String toMail = email;
        String title = "회원가입 인증 이메일 입니다.";
        String content = 
                "홈페이지를 방문해주셔서 감사합니다." +
                "<br><br>" + 
                "인증 번호는 " + checkNum + "입니다." + 
                "<br>" + 
                "해당 인증번호를 인증번호 확인란에 기입하여 주세요.";

        
       try {
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "utf-8");
            helper.setFrom(setFrom);
            helper.setTo(toMail);
            helper.setSubject(title);
            helper.setText(content,true);
            mailSender.send(message);
            
        }catch(Exception e) {
            e.printStackTrace();
        }
       
       String num = Integer.toString(checkNum);
       return num;

    }
	
    


}