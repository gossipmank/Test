package kr.co.OTZang.user.dto;

public class UserDTO {

	private String u_id;
	private String u_pwd;
	private String u_name;
	private String u_tel;
	private String u_birth;
	private String u_gen;
	private String u_code;
	private String u_add1;
	private String u_add2;
	private String u_add3;
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_pwd() {
		return u_pwd;
	}
	public void setU_pwd(String u_pwd) {
		this.u_pwd = u_pwd;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_tel() {
		return u_tel;
	}
	public void setU_tel(String u_tel) {
		this.u_tel = u_tel;
	}
	public String getU_birth() {
		return u_birth;
	}
	public void setU_birth(String u_birth) {
		this.u_birth = u_birth;
	}
	public String getU_gen() {
		return u_gen;
	}
	public void setU_gen(String u_gen) {
		this.u_gen = u_gen;
	}
	public String getU_code() {
		return u_code;
	}
	public void setU_code(String u_code) {
		this.u_code = u_code;
	}
	public String getU_add1() {
		return u_add1;
	}
	public void setU_add1(String u_add1) {
		this.u_add1 = u_add1;
	}
	public String getU_add2() {
		return u_add2;
	}
	public void setU_add2(String u_add2) {
		this.u_add2 = u_add2;
	}
	public String getU_add3() {
		return u_add3;
	}
	public void setU_add3(String u_add3) {
		this.u_add3 = u_add3;
	}
	@Override
	public String toString() {
		return "UserDTO [u_id=" + u_id + ", u_pwd=" + u_pwd + ", u_name=" + u_name + ", u_tel=" + u_tel + ", u_birth="
				+ u_birth + ", u_gen=" + u_gen + ", u_code=" + u_code + ", u_add1=" + u_add1 + ", u_add2=" + u_add2
				+ ", u_add3=" + u_add3 + "]";
	}
	

}