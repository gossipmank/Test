package kr.co.OTZang.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.OTZang.user.dao.UserDAO;
import kr.co.OTZang.user.dto.UserDTO;


@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	public int insert(UserDTO dto) {
		int result = userDAO.userInsert(dto);
		return result;
	}

	@Override
	public List<UserDTO> selectMember() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public int Login(UserDTO dto) throws Exception {
		return userDAO.Login(dto);
	}
	
	public UserDTO info(String u_id) {
		return userDAO.getUserInfo(u_id);
	}
	
	public int delete(String u_id) {
		int result = userDAO.userDelete(u_id);
		return result;
	}

}
