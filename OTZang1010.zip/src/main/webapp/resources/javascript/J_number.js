	var numdate = new Date();
		var numcomponents = [
	    	numdate.getYear(),
	 	    numdate.getMonth(),
		    numdate.getDate(),
		    numdate.getHours(),
		    numdate.getMinutes(),
		    numdate.getSeconds(),
		    numdate.getMilliseconds()
		];
	var numcode = numcomponents.join("");