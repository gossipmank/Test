	 //p_gprice
	   var list1 = new Array();
	   $("input[name=p_gprice]").each(function(index, item){
		   list1.push($(item).val());
	   });
	   console.log(list1);
	   document.getElementById('p_gprice2').value = list1;
	   
	 //p_gcode
	   var list2 = new Array();
	   $("input[name=p_gcode]").each(function(index, item){
		   list2.push($(item).val());
	   });
	   console.log(list2);
	   document.getElementById('p_gcode2').value = list2;
	   
	 //p_gname
	   var list3 = new Array();
	   $("input[name=p_gname]").each(function(index, item){
		   list3.push($(item).val());
	   });
	   console.log(list3);
	   document.getElementById('p_gname2').value = list3;
	   
	 //p_gbrand
	   var list4 = new Array();
	   $("input[name=p_gbrand]").each(function(index, item){
		   list4.push($(item).val());
	   });
	   console.log(list4);
	   document.getElementById('p_gbrand2').value = list4;
	   
	 //p_gcate
	   var list5 = new Array();
	   $("input[name=p_gcate]").each(function(index, item){
		   list5.push($(item).val());
	   });
	   console.log(list5);
	   document.getElementById('p_gcate2').value = list5;
	   
	 //p_gimg
	   var list6 = new Array();
	   $("input[name=p_gimg]").each(function(index, item){
		   list6.push($(item).val());
	   });
	   console.log(list6);
	   document.getElementById('p_gimg2').value = list6;
	   
	 //p_goption
	   var list7 = new Array();
	   $("input[name=p_goption]").each(function(index, item){
		   list7.push($(item).val());
	   });
	   console.log(list7);
	   document.getElementById('p_goption2').value = list7;
	   
	 //p_gcount
	   var list8 = new Array();
	   $("input[name=p_gcount]").each(function(index, item){
		   list8.push($(item).val());
	   });
	   console.log(list8);
	   document.getElementById('p_gcount2').value = list8;