
    var passflag2 = false;
    $(document).on('keyup', '#m_pwdup', function() { passwordUP();});
    function passwordUP() {
      var p1 = document.getElementById('m_pwdup').value;
      $.ajax({
    	  success : function(){
    		  if(p1.length < 4){
    		    $('#m_pwdupCheck').css('color','red').html('4글자 이상 입력해 주세요.');
    		    passflag2 = false;
    		  }
    		  else if(p1.length > 16){
  				$('#m_pwdupCheck').css('color','red').html('16글자 이하로 입력해주세요');
  				passflag2 = false;
  			  }
    		  else{
    			$('#m_pwdupCheck').css('color','green').html('사용가능한 비밀번호입니다.');
    			passflag2 = true;
    		  }
    	  }
    });
      return passflag2;
 };

    var passcheckflag2 = false;
    $(document).on('keyup', '#m_pwdup2', function() { passcheckUP();});
    function passcheckUP() {
      var p1 = document.getElementById('m_pwdup').value;
      var p2 = document.getElementById('m_pwdup2').value;
      $.ajax({
    	  success : function(){
    		  if(p2.length < 4){
      		    $('#m_pwdup2Check').css('color','red').html('4글자 이상 입력해 주세요.');
      		  passcheckflag2 = false;
      		  }
    		  else{
    		  	if( p1 != p2 ){
    		    	$('#m_pwdup2Check').css('color','red').html('비밀번호가 일치 하지 않습니다.');
    		    	passcheckflag2 = false;
    		  	}else{
    				$('#m_pwdup2Check').css('color','green').html('위에 입력한 비밀번호와 일치합니다.');
    				passcheckflag2 = true;
    		  	}
    		  }
    	  }
    });
      return passcheckflag2;
 };

	var delpassflag = false;
	
	$(document).on('keyup', '#m_pwd', function() { delpwcheck();});
function delpwcheck() {
 	var m_pwd = document.getElementById('m_pwd').value;//$('#id').val();
	$.ajax({
		url : "/passUpdateCheck.oz",
		type : "post",
		data : {m_pwd:m_pwd},
		dataType : 'json',
		success : function(result){
			if(m_pwd.length < 4){
				$('#m_pwdCheck').css('color','red').html('4글자 이상 입력해주세요');
				delpassflag = false;
				}
			else if(m_pwd.length > 16){
				$('#m_pwdCheck').css('color','red').html('16글자 이하로 입력해주세요');
				delpassflag = false;
				}
			else{
				if(result == 0){
					$('#m_pwdCheck').css('color','green').html('비밀번호가 확인되었습니다.');
					delpassflag = true;
				} else if (result == 1)  {
					$('#m_pwdCheck').html('필수 입력 사항입니다.').css('color','red');	
					delpassflag = false;
				} else if (result == 2)  {
					$('#m_pwdCheck').css('color','red').html('비밀번호를 다시 확인해주세요.');	
					delpassflag = false;
				}
			}
		},
		error : function() { location.href('/Main.sp');	 ch = false; }
	});
	return delpassflag;
	};

function validateDelPassword(){
	  var pw1 = document.getElementById("m_pwdup").value;
	  var pw2 = document.getElementById("m_pwdup2").value;

		if(pw1 != pw2) {  
		alert ("변경할 비밀번호와 확인이 일치하지 않습니다."); 
	      return false;  
	    } else {  
	    	if(delpassflag==false){
	    		alert ("비밀번호를 다시 확인해주세요."); 
	      		return false;
	    	}
	    	else{
	    		return true;
	    		}
	    	}
	    }
